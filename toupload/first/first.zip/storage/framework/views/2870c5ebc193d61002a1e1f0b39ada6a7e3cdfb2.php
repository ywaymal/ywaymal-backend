<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <AuthorizedClients></AuthorizedClients>
                <Clients></Clients>
                <PersonalAccessTokens></PersonalAccessTokens>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ywaymalbe\resources\views/zeroauthsetting.blade.php ENDPATH**/ ?>