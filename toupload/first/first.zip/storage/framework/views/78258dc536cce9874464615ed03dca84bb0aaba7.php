<div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="index.html" class="site_title"> <img style="width:42px;border-radius:22px;" src="<?php echo e(url('backend/asset/logo2.png')); ?>" alt="">    <span style="color:white;">YwayMal</span></a>
        </div>

        <div class="clearfix"></div>

        <!-- menu profile quick info -->
        <div class="profile clearfix">

            <div class="profile_info">
                <h2><?php echo e(Auth::user()->name); ?></h2>
            </div>
        </div>
        <!-- /menu profile quick info -->

        <br />

        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <ul class="nav side-menu">
                    
                        
                            
                            
                            
                        
                    
                    <li><a><i class="fa fa-edit"></i> Slider <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url("admin/sliderslist")); ?>">List</a></li>
                            <li><a href="<?php echo e(url("admin/addslider")); ?>">Add New Slider</a></li>

                        </ul>
                    </li>
                    <li><a><i class="fa fa-desktop"></i> Videos <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url("admin/videoslist")); ?>">List</a></li>
                            <li><a href="<?php echo e(url("admin/addvideo")); ?>">Add New Video</a></li>

                        </ul>
                    </li>

                    
                        
                            
                            
                        
                    
                    
                        
                            
                            
                            
                            
                            
                        
                    
                    
                        
                            
                                
                                

                            
                        
                    
                    <li><a><i class="fa fa-windows"></i>  News <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url("admin/newslist")); ?>">List</a></li>
                            <li><a href="<?php echo e(url("admin/addnews")); ?>">Add News</a></li>


                        </ul>
                    </li>
                </ul>
            </div>
            
                
                
                    
                        
                            
                            
                            
                            
                            
                        
                    
                    
                        
                            
                            
                            
                            
                            
                            
                        
                    
                    
                        
                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                            
                            
                            
                        
                    
                    
                
            

        </div>
        <!-- /sidebar menu -->

        <!-- /menu footer buttons -->
        <div class="sidebar-footer hidden-small">

            <small>&copy; Copyright &copy; <script>document.write(new Date().getFullYear());</script>, YwayMal Co.Ltd.All rights reserved </small>
        </div>
        <!-- /menu footer buttons -->
    </div>
</div>

<!-- top navigation -->
<div class="top_nav">
    <div class="nav_menu">
        <nav>
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo e(url('backend/asset/logo2.png')); ?>" alt=""><?php echo e(Auth::user()->name); ?>

                        <span class=" fa fa-angle-down"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                        
                        
                            
                                
                                
                            
                        
                        
                        <li><a href="login.html"  onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                        <li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </ul>
                </li>

                <li role="presentation" class="dropdown">
                    
                        
                        
                    
                    <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                        <li>
                            <a>
                                <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                            </a>
                        </li>
                        <li>
                            <a>
                                <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                                <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                            </a>
                        </li>
                        <li>
                            <div class="text-center">
                                <a>
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ywaymalbe\resources\views/layouts/menu.blade.php ENDPATH**/ ?>