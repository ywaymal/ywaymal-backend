<div class="x_content bs-example-popovers">
    <?php if(Session::has('Added')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <strong></strong> <?php echo e(Session::get('Added')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('Updated')): ?>
            <div class="alert alert-info alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <strong></strong> <?php echo e(Session::get('Updated')); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::has('Deleted')): ?>
            <div class="alert alert-danger alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <strong></strong> <?php echo e(Session::get('Deleted')); ?>

            </div>
        <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\ywaymalbe\resources\views/layouts/alert/add_edit_delete.blade.php ENDPATH**/ ?>