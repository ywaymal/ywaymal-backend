<?php $__env->startSection('body'); ?>
    <div class="container body">
        <div class="main_container">
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <!-- page content -->
            <div class="right_col" role="main">
                <?php echo $__env->make('layouts.alert.add_edit_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="">
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Video Detail </h3>
                        </div>

                    </div>

                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Video Detail</h2>

                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">

                                    <div class="col-md-7 col-sm-7 col-xs-12">
                                        <div class="product-image">
                                            <video width="320" height="240" controls>
                                                <source src="<?php echo e(url('backend/admin/videos/'.$video->link)); ?>" type="<?php echo e($video->video_type); ?>">
                                            </video>
                                        </div>

                                    </div>

                                    <div class="col-md-5 col-sm-5 col-xs-12" style="border:0px solid #e5e5e5;">

                                        <h3 class="prod_title"><?php echo e($video->title); ?></h3>

                                        <p> <?php echo e($video->description); ?></p>
                                        <br/>
                                        <p>City: <?php echo e($video->city); ?></p>
                                        <br/>

                                        <p>State: <?php echo e($video->state); ?></p>
                                        <br/>
                                        <p>Person: <?php echo e($video->person); ?></p>

                                        <br/>
                                        <p>Created_at: <?php echo e($video->created_at); ?></p>
                                        
                                        <br/>

                                        <div class="">
                                            <?php if($video->active == 1): ?>

                                                <ul class="list-inline prod_color">
                                                    <li>
                                                        <p>Active</p>
                                                        <div class="color bg-green"></div>
                                                    </li>
                                                     </ul>
                                            <?php else: ?>
                                                <ul class="list-inline prod_color">
                                                    <li>
                                                        <p>Deactive</p>
                                                        <div class="color bg-red"></div>
                                                    </li>
                                                </ul>
                                            <?php endif; ?>
                                        </div>
                                        <br/>



                                    </div>
                                    <div class="col-md-4">


                                    </div>
                                    <div class="col-md-4">


                                    </div>

                                    <div class="col-md-4">


                                        <form id="delete_form" action="<?php echo e(url('admin/deletevideo/')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($video->id); ?>" />
                                        </form>
                                        <button onclick="Delete()" type="submit" class="btn btn-danger">Delete</button>
                                        <a type="submit" href="<?php echo e(url('admin/videoedit/'.$video->id)); ?>" class="btn btn-success">Edit</a>


                                        <script>
                                          function Delete(){
                                              if(confirm('Are you sure want to delete this video')){
                                                  document.getElementById('delete_form').submit();
                                              }
                                          }


                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /page content -->

            <!-- footer content -->

            <!-- /footer content -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ywaymalbe\resources\views/admins/videodetail.blade.php ENDPATH**/ ?>