<?php $__env->startSection('body'); ?>
    <div class="container body">
        <div class="main_container">

        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- top navigation -->
            <!-- /top navigation -->

            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <?php echo $__env->make('layouts.alert.add_edit_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="page-title">
                        <div class="title_left">
                            <h3>Sliders List</h3>
                        </div>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_content">
                                    <p class="text-muted font-13 m-b-30">
                                    </p>
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>id</th>
                                            <th>Upload By</th>
                                            <th>Description</th>
                                            <th>Created At </th>
                                            <th> </th>
                                        </tr>
                                        </thead>


                                        <tbody>
                                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($s->id); ?></td>
                                                <td>
                                                    <?php
                                                    $upload_user=\Illuminate\Support\Facades\DB::table('users')->where('id',$s->uploader_id)->first()->name;
                                                    ?>
                                                    <?php echo e($upload_user); ?>

                                                </td>
                                                <td><?php echo e($s->description); ?></td>
                                                <td><?php echo e($s->created_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/slideredit/'.$s->id)); ?>" class="btn btn-success btn-xs">Edit</a>
                                                    <a href="<?php echo e(url('admin/sliderdetail/'.$s->id)); ?>" type="button" class="btn btn-info btn-xs">Detail</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                    </div>p
                </div>
            </div>
            <!-- /page content -->


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ywaymalbe\resources\views/admins/sliders/sliderslist.blade.php ENDPATH**/ ?>